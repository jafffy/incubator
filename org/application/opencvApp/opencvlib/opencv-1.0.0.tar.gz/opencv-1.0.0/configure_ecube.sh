#!/bin/bash
./configure --prefix=/usr/local/opencv  \
--host=arm-none-linux-gnueabi \
--target=arm-none-linux-gnueabi \
CXX=arm-none-linux-gnueabi-g++ \
AR=arm-none-linux-gnueabi-ar \
AS=arm-none-linux-gnueabi-as \
NM=arm-none-linux-gnueabi-nm \
STRIP=arm-none-linux-gnueabi-strip \
LD=arm-none-linux-gnueabi-ld \
RANLIB=arm-none-linux-gnueabi-ranlib \
--without-swig \
--without-python \
--without-xine \
--without-gtk \
--without-gthread \
--disable-apps \
--without-carbon \
--without-zlib \
--without-ffmpeg \
--without-1394libs \
--without-guicktime \
--disable-static \
--enable-shared


