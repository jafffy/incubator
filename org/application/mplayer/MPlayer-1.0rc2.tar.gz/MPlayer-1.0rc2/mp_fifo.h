#ifndef MP_FIFO_H
#define MP_FIFO_H

int mplayer_get_key(int fd);
void mplayer_put_key(int code);

#endif
