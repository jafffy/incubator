#ifndef CACHE2_H
#define CACHE2_H

extern void cache_uninit(stream_t *s);

#endif
