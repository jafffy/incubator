
#ifndef GUI_EQ_H
#define GUI_EQ_H

#include <gtk/gtk.h>

extern GtkWidget * Equalizer;

extern GtkWidget * create_Equalizer( void );
extern void ShowEqualizer( void );

#endif
