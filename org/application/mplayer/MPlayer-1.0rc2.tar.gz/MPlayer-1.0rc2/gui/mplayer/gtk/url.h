
#ifndef GUI_URL_H
#define GUI_URL_H

extern GtkWidget * URL;
extern int         gtkVURLDialogBox;

extern void ShowURLDialogBox( void );
extern GtkWidget * create_URL( void );

#endif
