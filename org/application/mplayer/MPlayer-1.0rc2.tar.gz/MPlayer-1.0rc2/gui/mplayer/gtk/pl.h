
#ifndef GUI_PL_H
#define GUI_PL_H

#include <gtk/gtk.h>

extern void ShowPlayList( void );
extern void HidePlayList( void );

extern GtkWidget * create_PlayList (void);

#endif
