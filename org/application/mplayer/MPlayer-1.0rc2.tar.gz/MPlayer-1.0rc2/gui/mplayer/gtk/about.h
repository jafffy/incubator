
#ifndef GUI_ABOUT_H
#define GUI_ABOUT_H

#include <gtk/gtk.h>

extern GtkWidget * About;

extern GtkWidget * create_About( void );
extern void ShowAboutBox( void );

#endif
