#define VERSION "1.0rc2-4.4.1"
#define MP_TITLE "MPlayer 1.0rc2-4.4.1 (C) 2000-2007 MPlayer Team"
