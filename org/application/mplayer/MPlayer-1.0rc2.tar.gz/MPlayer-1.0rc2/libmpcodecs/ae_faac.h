#ifndef MPAE_FAAC_H
#define MPAE_FAAC_H

#include "ae.h"

int mpae_init_faac(audio_encoder_t *encoder);

#endif
