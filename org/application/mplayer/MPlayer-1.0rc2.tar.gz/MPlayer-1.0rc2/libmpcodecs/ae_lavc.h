#ifndef AE_LAVC_H
#define AE_LAVC_H

#include "ae.h"

int mpae_init_lavc(audio_encoder_t *encoder);

#endif
