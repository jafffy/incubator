
void XA_MSGSM_Decoder(unsigned char *ibuf,unsigned short *obuf);
void XA_GSM_Decoder(unsigned char *ibuf,unsigned short *obuf);
void GSM_Init(void);


